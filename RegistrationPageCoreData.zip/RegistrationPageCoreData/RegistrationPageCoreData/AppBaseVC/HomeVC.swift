//
//  HomeVC.swift
//  RegistrationPageCoreData
//
//  Created by MacMiniOld on 02/11/18.
//  Copyright © 2018 Xongolab. All rights reserved.
//

import UIKit
import CoreData
import Foundation
public var mydata = [[String:String]]()
public var storecoreRecord = [RegistrationDetails]()
public var selectedMark:RegistrationDetails?
class HomeVC: UIViewController{

    @IBOutlet var center:NSLayoutConstraint!
    @IBOutlet var TxtFname: UITextField!
    @IBOutlet var TxtLname: UITextField!
    @IBOutlet var TxtUsrName: UITextField!
    @IBOutlet var TxtEmail: UITextField!
    @IBOutlet var TxtPassword: UITextField!
    @IBOutlet var TxtCnfPassword: UITextField!
    @IBOutlet var BtnRgstr: UIButton!
    @IBOutlet var RegisterVW: UIView!
    @IBOutlet var TxtUniqueId: UITextField!
    @IBOutlet var SearchID: UITextField!
    @IBOutlet var BtnSearchRecord: UIButton!
    @IBOutlet var BtnUpdateRecord: UIButton!
    @IBOutlet var LblMenuLogo: UILabel!
    var Fname:String?
    var Lname:String?
    var user:String?
    var email:String?
    var pass:String?
    var confirm:String?
    var objectId = NSManagedObjectID()
    var contex = NSManagedObjectContext()

    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        BtnUpdateRecord.isHidden = true
        LblMenuLogo.text = "Register"
        if let s = selectedMark{
            TxtFname.text = s.firstName
            TxtLname.text = s.lastName
            TxtUsrName.text = s.user
            TxtEmail.text = s.email
            TxtPassword.text = s.password
            TxtUniqueId.text = s.uniqueId
        }
        
        
        Fname = TxtFname.text
        Lname = TxtLname.text
        user = TxtUsrName.text
        email = TxtEmail.text
        pass = TxtPassword.text
        confirm = TxtCnfPassword.text
        
        //      MARKS:-- Update Button
        
        BtnUpdateRecord.layer.cornerRadius = 8
        BtnUpdateRecord.layer.borderWidth = 2
        BtnUpdateRecord.layer.borderColor = UIColor.red.cgColor
        BtnUpdateRecord.backgroundColor = .clear
        
        
        // MARKS:-- Search Button
        
        BtnSearchRecord.layer.cornerRadius = 8
        BtnSearchRecord.layer.borderWidth = 2
        BtnSearchRecord.layer.borderColor = UIColor.red.cgColor
        BtnSearchRecord.backgroundColor = .clear
        
        
//        MARKS:-- Registration Button
  
        RegisterVW.layer.cornerRadius = 40
        BtnRgstr.layer.cornerRadius = 14
        BtnRgstr.layer.borderWidth = 2
        BtnRgstr.layer.borderColor = UIColor.red.cgColor
        BtnRgstr.backgroundColor = .clear
        
        
       
       
        //MARKS:-- Txtfiels Layout Function
        textfieldlayout()
        
        UIView.animate(withDuration: 0.8, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
            self.center.constant = 0
            self.view.layoutIfNeeded()
        }, completion: nil)

      
    }
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }

    func textfieldlayout(){
        //Marks:-- FirstName
        TxtFname.backgroundColor = .clear
        TxtFname.attributedPlaceholder = NSAttributedString(string: "Enter First Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtLname.backgroundColor = .clear
        TxtLname.attributedPlaceholder = NSAttributedString(string: "Enter Last Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtUsrName.backgroundColor = .clear
        TxtUsrName.attributedPlaceholder = NSAttributedString(string: "Enter Username Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtEmail.backgroundColor = .clear
        TxtEmail.attributedPlaceholder = NSAttributedString(string: "Enter Email Id",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtPassword.backgroundColor = .clear
        TxtPassword.attributedPlaceholder = NSAttributedString(string: "Please Enter Password",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtCnfPassword.backgroundColor = .clear
        TxtCnfPassword.attributedPlaceholder = NSAttributedString(string: "Please Conf. Enter Password",attributes: [NSAttributedStringKey.foregroundColor: UIColor.yellow])
        TxtUniqueId.backgroundColor = .clear
        TxtUniqueId.attributedPlaceholder = NSAttributedString(string: "Please Enter Unique Id",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        
        SearchID.attributedPlaceholder = NSAttributedString(string: "Search Id",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        

        
        TxtFname.rightViewMode = UITextFieldViewMode.always
        
        let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image1 = UIImage(named: "usernameL")
        imageView1.image = image1
        TxtFname.rightView = imageView1
        
        //Marks:-- FirstName
        TxtLname.rightViewMode = UITextFieldViewMode.always
        let imageView2 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image2 = UIImage(named: "usernameL")
        imageView2.image = image2
        TxtLname.rightView = imageView2
        
        //Marks:-- Username
        TxtUsrName.rightViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = UIImage(named: "UserL")
        imageView.image = image
        TxtUsrName.rightView = imageView
        
        //Marks:-- Email
        TxtEmail.rightViewMode = UITextFieldViewMode.always
        let imageView4 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image4 = UIImage(named: "emailL")
        imageView4.image = image4
        TxtEmail.rightView = imageView4

        //Marks:-- Password

        TxtPassword.rightViewMode = UITextFieldViewMode.always
        let imageView5 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image5 = UIImage(named: "PassL")
        imageView5.image = image5
        TxtPassword.rightView = imageView5
        
        //Marks:-- Confirm Password
        TxtCnfPassword.rightViewMode = UITextFieldViewMode.always
        let imageView6 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image6 = UIImage(named: "PassL")
        imageView6.image = image6
        TxtCnfPassword.rightView = imageView6
    }
   
    func validation(){
        let alertController = UIAlertController(title: "Error", message: "Please Enter Valid Email Address", preferredStyle: .alert)
        // Create the actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
            UIAlertAction in
            print("succeffully done")
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func emailAlreadyExist(){
        let alertEmail = UIAlertController(title: "Error", message: "Email is Already Exist", preferredStyle: .alert)
        // Create the actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
            UIAlertAction in
            print("succeffully done")
        }
        alertEmail.addAction(okAction)
        self.present(alertEmail, animated: true, completion: nil)
    }
    
    func alertaction(){
        if (TxtFname.text == "" || TxtLname.text == "" || TxtUsrName.text == "" || TxtEmail.text == "" || TxtPassword.text=="" || TxtCnfPassword.text == "" || TxtUniqueId.text == ""){
            let alertController = UIAlertController(title: "Error", message: "Please Enter Valid Data", preferredStyle: .alert)
            // Create the actions
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
                UIAlertAction in
                //     print("OK Pressed")
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
                UIAlertAction in
                //  print("Cancel Pressed")
            }
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    func clearTextfield ()
    {
        TxtFname.text = ""
        TxtLname.text = ""
        TxtUsrName.text = ""
        TxtEmail.text = ""
        TxtPassword.text = ""
        TxtCnfPassword.text = ""
        TxtUniqueId.text = ""
    }
    
    @IBAction func BtnBackToHome(_ sender: UIButton) {
    
        let navigate = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(navigate, animated: true)
    }
    
    @IBAction func BtnRegister(_ sender: UIButton) {
       if (TxtFname.text == "" || TxtLname.text == "" || TxtUsrName.text == "" || TxtEmail.text == "" || TxtPassword.text=="" || TxtCnfPassword.text == "" || TxtUniqueId.text == ""){
            alertaction()
        }else if !isValidEmail(testStr: TxtEmail.text!){
            validation()
        }else if isValidEmail(testStr: TxtEmail.text!)
       {
        for get in mydata{

            for search in get {

                if(search.value == TxtEmail.text){
                    emailAlreadyExist()
                    return
                }
            }
        }
        let Dictionry = ["firstName":(TxtFname.text)!,"lastName":(TxtLname.text)!,"user":(TxtUsrName.text)!,"email":(TxtEmail.text)!,"password":(TxtPassword.text)!,"Confirm":(TxtCnfPassword.text)!,"uniqueId":(TxtUniqueId.text)!]
        
        //MARKS:-- New 1
    
        DatabaseHelper.shareInstance.Save(object:Dictionry)
        
        mydata.append(Dictionry)
        
        let navigate = self.storyboard?.instantiateViewController(withIdentifier: "ShowRegisterVC") as! ShowRegisterVC
        
        
        self.navigationController?.pushViewController(navigate, animated: true)
        
      //  navigate.arraydata = mydata
        
        clearTextfield()
      }else{
        alertaction()
        }
    }
    
    @IBAction func BtnSearchRecord(_ sender: UIButton) {
    
        LblMenuLogo.text = "Update Record"
        BtnRgstr.isHidden = true
        BtnUpdateRecord.isHidden = false
        if (SearchID.text?.isEmpty)!
        {
            alertaction()
        }
        else
        {
            selectedMark = DatabaseHelper.shareInstance.getStudentByUniqueID(uniqueId: SearchID.text!)[0]

        
            TxtFname.text = selectedMark?.firstName
            TxtLname.text = selectedMark?.lastName
            TxtUsrName.text = selectedMark?.user
            TxtEmail.text = selectedMark?.email
            TxtPassword.text = selectedMark?.password
            TxtUniqueId.text = selectedMark?.uniqueId
            
            objectId = (selectedMark?.objectID)!
            TxtUniqueId.isUserInteractionEnabled = false
            SearchID.text = ""
        }
    
    }
    
    @IBAction func BtnUpdate(_ sender: UIButton) {
        LblMenuLogo.text = "Update Record"
        if (TxtFname.text == "" || TxtLname.text == "" || TxtUsrName.text == "" || TxtEmail.text == "" || TxtPassword.text=="" || TxtCnfPassword.text == "" || TxtUniqueId.text == ""){
            
            alertaction()
            
        }else{
        let Dictionry = ["firstName":TxtFname.text!,"lastName":TxtLname.text!,"user":TxtUsrName.text!,"email":TxtEmail.text!,"password":TxtPassword.text!,"uniqueId":TxtUniqueId.text!]
            
            TxtUniqueId.isUserInteractionEnabled = false
            
          //  let dict = ["name":txtName.text!,"email": txtEmail.text!,"number":txtNumber.text!,"city":txtCity.text! , "stdID": txtID.text!]
        
            DatabaseHelper.shareInstance.updateRecord(id: objectId, dictionary: Dictionry)
        
          //  BtnUpdateRecord.setTitle("Save", for: .normal)
        
        clearTextfield()
        
        BtnRgstr.isHidden = false
        BtnUpdateRecord.isHidden = true
        TxtUniqueId.isUserInteractionEnabled = true
            LblMenuLogo.text = "Register"
    }

}
    override func viewDidAppear(_ animated: Bool) {
        clearTextfield()
    }
    
    
}
    
   
    

