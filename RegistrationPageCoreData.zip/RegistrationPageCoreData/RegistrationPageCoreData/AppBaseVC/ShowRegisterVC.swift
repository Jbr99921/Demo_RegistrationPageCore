//
//  ShowRegisterVC.swift
//  RegistrationPageCoreData
//
//  Created by MacMiniOld on 05/11/18.
//  Copyright © 2018 Xongolab. All rights reserved.
//

import UIKit

import CoreData


class ShowRegisterVC: UIViewController,UITableViewDataSource,UITableViewDelegate{
   
    
    @IBOutlet var AddRecord: UIButton!
    @IBOutlet var UpdateRecord: UIButton!
    @IBOutlet var TblView: UITableView!
    var register: [NSManagedObject] = []
    
    var arraydata = [String:String]()
    
    override func viewWillAppear(_ animated: Bool) {
        
        let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let context:NSManagedObjectContext = appDel.persistentContainer.viewContext

        TblView.reloadData()
        
    }
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.TblView.reloadData()

        
        
        
//        UpdateRecord.isHidden = true
//        AddRecord.isHidden = true
        TblView.layer.cornerRadius = 30
       
        AddRecord.layer.cornerRadius = 14
        AddRecord.layer.borderWidth = 1
        AddRecord.layer.borderColor = UIColor.red.cgColor
        
        UpdateRecord.layer.cornerRadius = 14
        UpdateRecord.layer.borderWidth = 1
     //   UpdateRecord.layer.borderColor = UIColor.red.cgColor
        
//        let nib = UINib.init(nibName: "RegisterCell", bundle: nil)
//        self.TblView.register(nib, forCellReuseIdentifier: "RegisterCell")
        storecoreRecord = DatabaseHelper.shareInstance.GetShowData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
  //  return arrRegisterItems.count
     return storecoreRecord.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let indexpath = self.TblView.indexPathForSelectedRow
        let row = indexPath.row
        
        let reference =  storecoreRecord[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "RegisterCell", for: indexPath) as! RegisterCell
        
//        if cell != nil{
//            cell = UITableViewCell(style:.subtitle, reuseIdentifier: "RegisterCell") as! RegisterCell
//        }
//        cell.Fname.text = storecoreRecord[indexPath.row].firstName
//        cell.Lname.text = storecoreRecord[indexPath.row].lastName
//        cell.User.text = storecoreRecord[indexPath.row].userName
//        cell.Email.text = storecoreRecord[indexPath.row].email
//        cell.Pass.text = storecoreRecord[indexPath.row].password

        cell.Fname.text = reference.firstName
        cell.Lname.text = reference.lastName
        cell.User.text = reference.user
        cell.Email.text = reference.email
        cell.Pass.text = reference.password
        cell.UniqueID.text = reference.uniqueId
       // cell.UniqueID.text = reference.uniqueId
//        cell.Fname.text = reference.value(forKey: "FName") as? String
//        cell.Lname.text = reference.value(forKeyPath: "LName") as? String
//        cell.User.text = reference.value(forKeyPath: "user") as? String
//        cell.Email.text = reference.value(forKeyPath: "Email") as? String
//        cell.Pass.text = reference.value(forKeyPath: "Password") as? String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
  
        
      let navigate = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EditVC") as! EditVC
        let celldetail = tableView.cellForRow(at: indexPath) as! RegisterCell
       
        navigate.Fname = celldetail.Fname.text
        navigate.Lname = celldetail.Lname.text
        navigate.user = celldetail.User.text
        navigate.email = celldetail.Email.text
        navigate.pass = celldetail.Pass.text
        navigate.UniqueID = celldetail.UniqueID.text

        
        self.navigationController?.pushViewController(navigate, animated: true)
         self.TblView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete{
       
        //MARKS:-- For Delete Row From Table Cell

//        if (editingStyle == UITableViewCellEditingStyle.delete){
//            if let tv = TblView{
//                TblView.reloadData()
//                storecoreRecord.remove(at: indexPath.row)
//
//                tv.deleteRows(at: [indexPath], with: .left)
//                }
//            }
        
            let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate
            let context:NSManagedObjectContext = appDel.persistentContainer.viewContext
            context.delete(storecoreRecord[indexPath.row])
            storecoreRecord.remove(at: indexPath.row)
            
            do{
                try context.save()
            }catch{
                return
            }
        self.TblView.deleteRows(at: [indexPath], with: .left)
        }else{
            return
        }
    }
    
    @IBAction func AddRecords(_ sender: UIButton) {
   
       // let navigate = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        //self.navigationController?.popViewController(animated: true)
        
    let navigat = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        self.navigationController?.pushViewController(navigat, animated: true)
        
    }
    
    @IBAction func UpdateRecord(_ sender: UIButton) {
     
    
    }
    
        
}
        
 

