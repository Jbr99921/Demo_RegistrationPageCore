//
//  RegisterCell.swift
//  RegistrationPageCoreData
//
//  Created by MacMiniOld on 05/11/18.
//  Copyright © 2018 Xongolab. All rights reserved.
//

import UIKit

class RegisterCell: UITableViewCell {

    
    @IBOutlet var Fname: UILabel!
    @IBOutlet var Lname: UILabel!
    @IBOutlet var User: UILabel!
    @IBOutlet var Email: UILabel!
    @IBOutlet var Pass: UILabel!
    @IBOutlet var UniqueID: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
